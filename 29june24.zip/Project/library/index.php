

<?php /* CSS */  ?> 
    <?php /* Main index.css */  ?>
        <link rel="stylesheet" href="css/index.css">

    <?php /* bootstrap css */  ?>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> 

    <?php /* font awesome  */  ?>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <?php /* Tablats View */  ?>
        <link rel="stylesheet" href="css/tablets_view.css">

        
        <?php /* JS */  ?> 
    <?php /* bootstrap js */  ?>
        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <?php /* jQyery  */  ?>
        <script src="js/jquery.js"></script>

    <?php /* Main index.js  */  ?>
        <script src="js/index.js"></script>

