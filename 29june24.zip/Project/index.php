<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GadgetGalaxy</title>
    <?php  require_once "library/index.php";  ?>
</head>

<body>

    <?php 
        require_once "core/helpers/menuhelper.php";  
        require_once "core/classes/class.header.php";
        require_once "core/classes/class.managecategory.php";
        require_once "core/view/header.php";
        require_once "core/view/main.php";
    ?>
    
    
    
    
</body>

</html>