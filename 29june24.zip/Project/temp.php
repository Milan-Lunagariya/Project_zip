<!-- Header -->
<header class="header_container"> 
    <div class="fixed_nav">
      <div class="left">
        <div class="logo">
          <img src="images/flipcart.png" height="100" class="image" alt="GadgetGalaxy">
        </div> 
      </div>

      <div class="center">
        <div class="searchbar">
          <!-- <label for="nav_search"></label> -->
          <input type="search" name="" placeholder=">Search for produc, brands and more" class="nav_search">
        </div>
      </div>

      <div class="right"> 
        <div class="cart_button">
          <i class="fa-solid fa-cart-shopping button cart_icon"></i>
        </div>
        <div class="login_button">
          <i class="fa-regular fa-user button"></i>
		</div> 
      </div>
    </div> 
</header>